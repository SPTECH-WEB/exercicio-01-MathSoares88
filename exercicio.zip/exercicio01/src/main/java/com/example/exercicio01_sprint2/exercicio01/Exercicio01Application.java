package com.example.exercicio01_sprint2.exercicio01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercicio01Application {

	public static void main(String[] args) {
		SpringApplication.run(Exercicio01Application.class, args);
	}

}
